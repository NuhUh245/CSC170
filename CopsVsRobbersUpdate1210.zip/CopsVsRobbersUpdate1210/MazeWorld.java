import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class MazeWorld extends World
{
    private GreenfootSound bgMusic =  new  GreenfootSound("Piano Sonata No 11 in A Major K 331_ III Alla Turca_ Allegretto.mp3");
    private int timer = 0;

    /**
     * Constructor for objects of class MazeWorld.
     */
    public MazeWorld()
    {
        super(600, 400, 1);
        prepare();
        bgMusic.playLoop();
    }

    /**
     * 
     */
    public void act()
    {
        timer = timer + 1;
        showText("Time: " + timer, 50, 20);
    }

    /**
     * 
     */
    public int getTimeScore()
    {
        return timer;
    }

    /**
     * 
     */
    private void prepare()
    {
        addObject( new  cop(), 100, 200);
        addObject( new  robber(), 500, 200);
        addObject(new ghost(), 100, 200);
    }
}
