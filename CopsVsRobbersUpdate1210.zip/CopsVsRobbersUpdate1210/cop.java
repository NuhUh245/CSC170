import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class cop extends Actor
{
    private int timer = 0;

    private int slowTimer = 0;
    private int normalSpeed = 3;
    private int slowSpeed = 1;
    
    /**
     * Act - do whatever the cop wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public void act1() {
        checkGhostCollision();
        moveCop();
    }
    private void moveCop()
    {
        int speed;
        if (slowTimer > 0) {
            speed = slowSpeed;
            slowTimer--;
        } else {
            speed = normalSpeed;
        }
        
        if (Greenfoot.isKeyDown("left")) turn(-3);
        if (Greenfoot.isKeyDown("right")) turn(3);
        if (Greenfoot.isKeyDown("up")) move(speed);
    }
    private void checkGhostCollision() {
        if (isTouching(ghost.class)) {
            slowTimer = 120;
        }
    }
    public void act()
    {
        if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - 2);
        }
        if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + 2);
        }
        if (Greenfoot.isKeyDown("left")) {
            setLocation(getX() - 2, getY());
        }
        if (Greenfoot.isKeyDown("right")) {
            setLocation(getX() + 2, getY());
        }
        if (isTouching(robber.class)) {
            MazeWorld world = (MazeWorld)getWorld();
           
            Greenfoot.playSound("Ha Got Em.mp3");
            
            int score = world.getTimeScore();
            getWorld().showText("you caught the robber!" + " " + "Score of: " + score, 300, 200);
            Greenfoot.stop();
        }
    }
}
