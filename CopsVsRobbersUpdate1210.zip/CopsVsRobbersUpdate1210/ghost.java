import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class ghost extends Actor
{

 public ghost() {
     setImage("ghost.png");
 }
    public void act()
    {
        move(1);
        if (Greenfoot.getRandomNumber(100) < 4) {
            turn(Greenfoot.getRandomNumber(121) - 60);
        }
        if (isAtEdge()) {
            turn(100);
        }
    }
}
