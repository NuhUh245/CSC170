// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class robber extends Actor
{

    /* WARNING: This file is auto-generated and any changes to it will be overwritten*/

    /**
     * Act - do whatever the robber wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        int dx = Greenfoot . getRandomNumber ( 11 ) - 3;
        int dy = Greenfoot . getRandomNumber ( 11 ) - 3;
        int newX = ( int ) ( getX ( ) + dx );
        int newY = ( int ) ( getY ( ) + dy );
        setLocation ( newX , newY );
        if (isAtEdge ( )) {
            setLocation ( Greenfoot . getRandomNumber ( getWorld ( ) . getWidth ( ) ) , Greenfoot . getRandomNumber ( getWorld ( ) . getHeight ( ) ) );
        }
        if (getImage ( ) . getTransparency ( ) == 225) {
            getImage ( ) . setTransparency ( 50 );
        }
        else {
            getImage ( ) . setTransparency ( 255 );
        }
    }
}
