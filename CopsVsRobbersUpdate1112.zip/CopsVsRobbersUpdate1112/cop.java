import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class cop extends Actor
{

    /**
     * Act - do whatever the cop wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - 2);
        }
        if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + 2);
        }
        if (Greenfoot.isKeyDown("left")) {
            setLocation(getX() - 2, getY());
        }
        
        if (Greenfoot.isKeyDown("right")) {
            setLocation(getX() + 2, getY());
        }
        if (isTouching(robber.class)) {
            getWorld().showText("you caught the robber!", 300, 200);
            Greenfoot.stop();
        }
        
    }
}
