// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class MazeWorld extends World
{

    /**
     * Constructor for objects of class MazeWorld.
     */
    public MazeWorld()
    {
        super(600, 400, 1);
        prepare();
        
    }

    /**
     * 
     */
    private void prepare()
    {
        
        addObject( new cop(), 100, 200);
        
        addObject( new robber(), 500, 200);
        
        
    }
}
